package com.example.masonfibkins.lab_5;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void findMeal(View view) {
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton2);
        boolean location = toggle.isChecked();
        String perfectMeal;
        if (location) {
            perfectMeal = "Salad ";
        } else {
            perfectMeal = "Chicken ";
        }
        Spinner meal = (Spinner) findViewById(R.id.spinner);
        String mealType = String.valueOf(meal.getSelectedItem());

        RadioGroup cost = (RadioGroup) findViewById(R.id.radioGroup);
        int cost_id = cost.getCheckedRadioButtonId();

        if (location) {
            switch (mealType) {
                case "breakfast":
                    perfectMeal = "Oatmeal ";
                    break;
                case "lunch":
                    perfectMeal = "Tuna Salad ";
                    break;
                case "dinner":
                    perfectMeal = "Pasta ";
                    break;
                default:
                    perfectMeal = "Salad ";
            }
                } else {
                    if(cost_id==R.id.radioButton2){
                        perfectMeal= "Take-out";
                    }
                    switch (mealType) {
                        case "breakfast":
                            perfectMeal = "Eggs ";
                            break;
                        case "lunch":
                            perfectMeal = "Egg Salad ";
                            break;
                        case "dinner":
                            perfectMeal = "Salmon ";
                            break;
                        default:
                            perfectMeal = "Chicken ";
                    }
                }




            TextView mealSelection = (TextView) findViewById(R.id.mealTextView);
            mealSelection.setText(perfectMeal + "is your perfect meal");
        }



    public void sayOkay(View view) {
        TextView okayText = (TextView) findViewById(R.id.message);
        okayText.setText("This is lab 5");
        EditText name = (EditText) findViewById(R.id.editText);
        String nameValue = name.getText().toString();
        okayText.setText("This is " + nameValue + "'s lab 5");

        Context context = getApplicationContext();
        CharSequence text = "Let's make a meal";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }
}

